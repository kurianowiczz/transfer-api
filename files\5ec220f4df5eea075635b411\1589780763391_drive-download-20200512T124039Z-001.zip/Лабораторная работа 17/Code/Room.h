#ifndef ROOM_H_HEADER_INCLUDED_A1981137
#define ROOM_H_HEADER_INCLUDED_A1981137

// Identify room of the hotel
//##ModelId=5E63AFD5031F
class Room
{
    //##ModelId=5E63B65802F4
    Integer RoomId;
    //##ModelId=5E63B664028D
    Integer BedsCount;
};



#endif /* ROOM_H_HEADER_INCLUDED_A1981137 */
