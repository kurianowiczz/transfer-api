#include "StorageManager.h"

//##ModelId=5E54250B01FB
Boolean StorageManager::SaveRequest(Integer RequestId)
{
}

