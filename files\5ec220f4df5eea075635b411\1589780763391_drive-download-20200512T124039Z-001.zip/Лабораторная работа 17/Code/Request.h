#ifndef REQUEST_H_HEADER_INCLUDED_A1987DAF
#define REQUEST_H_HEADER_INCLUDED_A1987DAF

// Store information about client request
// @author Anton Mordik, Alexander Shantyr
// @version 1.0
//##ModelId=5E638ED900D4
class Request
{
  public:
    // Creating new request entity
    // @since 1.0
    // @see Client#ClientId, Room#RoomId
    // @param ClientId - identifier of Client
    // @param RoomId - identifier of Room
    // @param ReservationDate - client's choosen date
    // @return identifier of new request
    //##ModelId=5E63A8800393
    Integer Create(Integer ClientId, Integer RoomId, Date ReservationDate);

  private:
    // Identifier of request
    //##ModelId=5E63ABAA011F
    Integer RequestId;
    // Requested date
    //##ModelId=5E63ABE500C7
    Date ReservationDate;
    // Identifier of Room { @link Room#RoomId }
    //##ModelId=5E63B77903C1
    Integer RoomId;
    // Identifier of Client { @link Client#ClientId }
    //##ModelId=5E63B7860060
    Integer ClientId;
};

#endif /* REQUEST_H_HEADER_INCLUDED_A1987DAF */
