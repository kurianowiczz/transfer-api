#include "DataInput.h"

//##ModelId=5E5424640345
Boolean DataInput::OpenForm()
{
}

//##ModelId=5E5424890129
Boolean DataInput::SubmitData()
{
}

//##ModelId=5E54251B00D2
Boolean DataInput::ReturnSuccess()
{
}

//##ModelId=5E63B1410121
RoomId DataInput::ChooseRoom()
{
}

//##ModelId=5E63B1500119
Date DataInput::InputDate()
{
}

