#ifndef RESERVATIONMANAGER_H_HEADER_INCLUDED_A1987F8E
#define RESERVATIONMANAGER_H_HEADER_INCLUDED_A1987F8E

// Manipulate client data for reservation
//##ModelId=5E54233202A5
class ReservationManager
{
  public:
    // Send query on request creation with provided data
    //##ModelId=5E5424A20068
    Boolean SaveData(Integer ClientId, Integer RoomId, Date Date);

    // Check client data for reservation on validity 
    //##ModelId=5E5424BF0255
    Boolean ValidateData(Integer ClientId, Integer RoomId, Date Date);

};



#endif /* RESERVATIONMANAGER_H_HEADER_INCLUDED_A1987F8E */
