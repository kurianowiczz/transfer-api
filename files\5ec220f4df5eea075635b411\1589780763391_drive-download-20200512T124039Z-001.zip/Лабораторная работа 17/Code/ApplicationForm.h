#ifndef APPLICATIONFORM_H_HEADER_INCLUDED_A1986B82
#define APPLICATIONFORM_H_HEADER_INCLUDED_A1986B82

// Main form of the application
//##ModelId=5E551A600105
class ApplicationForm
{
  public:
    // Open main form of the application
    //##ModelId=5E551AF2024D
    Boolean CreateForm();

};



#endif /* APPLICATIONFORM_H_HEADER_INCLUDED_A1986B82 */
