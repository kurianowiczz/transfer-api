#include "ReservationManager.h"

//##ModelId=5E5424A20068
Boolean ReservationManager::SaveData(Integer ClientId, Integer RoomId, Date Date)
{
}

//##ModelId=5E5424BF0255
Boolean ReservationManager::ValidateData(Integer ClientId, Integer RoomId, Date Date)
{
}

