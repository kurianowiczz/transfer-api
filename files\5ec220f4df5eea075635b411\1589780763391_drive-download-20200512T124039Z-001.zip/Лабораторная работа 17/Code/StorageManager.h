#ifndef STORAGEMANAGER_H_HEADER_INCLUDED_A1985EDE
#define STORAGEMANAGER_H_HEADER_INCLUDED_A1985EDE

// Provide methods for adding data to the database
//##ModelId=5E54238F0336
class StorageManager
{
  public:
    // Add request to the database
    //##ModelId=5E54250B01FB
    Boolean SaveRequest(Integer RequestId);

};



#endif /* STORAGEMANAGER_H_HEADER_INCLUDED_A1985EDE */
