#include "Request.h"

//##ModelId=5E63A8800393
Integer Request::Create(Integer ClientId, Integer RoomId, Date ReservationDate)
{
}

