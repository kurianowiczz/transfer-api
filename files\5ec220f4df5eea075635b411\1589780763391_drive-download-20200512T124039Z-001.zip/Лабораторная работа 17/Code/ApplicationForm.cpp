#include "ApplicationForm.h"

//##ModelId=5E551AF2024D
Boolean ApplicationForm::CreateForm()
{
}

