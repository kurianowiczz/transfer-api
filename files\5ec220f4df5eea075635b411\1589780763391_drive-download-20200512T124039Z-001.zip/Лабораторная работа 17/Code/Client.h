#ifndef CLIENT_H_HEADER_INCLUDED_A198377D
#define CLIENT_H_HEADER_INCLUDED_A198377D

// Store data about client, used to identify requests
//##ModelId=5E63AFDD0021
class Client
{
    //##ModelId=5E63B5F80398
    Integer ClientId;
    //##ModelId=5E63B6270320
    String Surname;
    //##ModelId=5E63B6040061
    String Name;
    //##ModelId=5E63B60A00D8
    String PassportNumber;
};



#endif /* CLIENT_H_HEADER_INCLUDED_A198377D */
