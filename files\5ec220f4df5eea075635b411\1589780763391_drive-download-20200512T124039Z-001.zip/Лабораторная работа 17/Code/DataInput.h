#ifndef DATAINPUT_H_HEADER_INCLUDED_A1986D25
#define DATAINPUT_H_HEADER_INCLUDED_A1986D25

// Boundary between reservation data input form and this data manipulation
// class
//##ModelId=5E54230F02F7
class DataInput
{
  public:
    // Open form for input reservation data
    //##ModelId=5E5424640345
    Boolean OpenForm();

    // Send reservation data to the manipulation class
    //##ModelId=5E5424890129
    Boolean SubmitData();

    // Display info about successfull added reservation request
    //##ModelId=5E54251B00D2
    Boolean ReturnSuccess();

    // Used for select a room
    //##ModelId=5E63B1410121
    RoomId ChooseRoom();

    // Used for input reservation date
    //##ModelId=5E63B1500119
    Date InputDate();

};



#endif /* DATAINPUT_H_HEADER_INCLUDED_A1986D25 */
